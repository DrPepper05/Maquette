import { Suspense, lazy, useEffect, useRef, useState } from "react";
import { animate, motion, useMotionValue, useReducedMotion, useTransform, type MotionValue } from "motion/react";
import { projects, type Project, PATH } from "./projects";
import { smooth, wrap } from "./CrumplePlane";
import "./studio.css";

const CrumpleCanvas = lazy(() => import("./CrumpleCanvas"));
const N = projects.length;
const canWebGL2 = () => { try { return !!document.createElement("canvas").getContext("webgl2"); } catch { return false; } };
const pad = (n: number) => String(n).padStart(2, "0");

/** Static stand-in for the living canvas: layered washes from the piece's own palette. */
const artCss = (p: Project) => [
  `radial-gradient(120% 90% at 22% 18%, ${p.palette[2]}40, transparent 62%)`,
  `radial-gradient(100% 80% at 78% 82%, ${p.palette[1]}66, transparent 58%)`,
  `radial-gradient(60% 45% at 60% 35%, ${p.palette[2]}22, transparent 70%)`,
  `linear-gradient(165deg, ${p.palette[0]}, ${p.palette[3]})`,
].join(",");

/** Double helix that twists along the pieces' sine path (offsets run perpendicular to the curve). */
const TWIST = (8 * Math.PI) / N;
const strand = (phase: number, A = 2.4) => {
  const pts: string[] = [], aspect = 1.6;
  for (let o = -6.5; o <= 6.5; o += 0.04) {
    const x = 50 + o * PATH.gap, y = 50 + Math.sin(o * PATH.freq) * PATH.amp;
    const dx = PATH.gap * aspect, dy = Math.cos(o * PATH.freq) * PATH.amp * PATH.freq;
    const len = Math.hypot(dx, dy), tw = Math.sin(o * TWIST + phase) * A;
    pts.push(`${pts.length ? "L" : "M"}${(x - (dy / len) * tw / aspect).toFixed(2)} ${(y + (dx / len) * tw).toFixed(2)}`);
  }
  return pts.join(" ");
};
const TRAIL_A = strand(0), TRAIL_B = strand(Math.PI), TRAIL_C = strand(0, 0);

function Artwork({ p, i, progress, gl, onPick }: { p: Project; i: number; progress: MotionValue<number>; gl: boolean; onPick: (i: number) => void }) {
  const off = useTransform(progress, (v) => wrap(i - v, N));
  const x = useTransform(off, (o) => `${o * PATH.gap}vw`);
  const y = useTransform(off, (o) => `${Math.sin(o * PATH.freq) * PATH.amp}vh`);
  const rotateY = useTransform(off, (o) => -o * 12);
  const scale = useTransform(off, (o) => 1 - Math.min(Math.abs(o), 1.6) * 0.14);
  const opacity = useTransform(off, (o) => (gl ? 1 - smooth(0.05, 0.3, Math.abs(o)) : Math.max(0, 1 - (Math.abs(o) - 1.2))));
  const z = useTransform(off, (o) => 100 - Math.round(Math.abs(o) * 10));
  return (
    <motion.a href={p.href} aria-label={`${p.title}: ${p.tagline}`} aria-roledescription="artwork"
      onClick={(e) => { if (Math.abs(off.get()) > 0.3) { e.preventDefault(); onPick(i); } }}
      style={{ x, y, rotateY, scale, opacity, zIndex: z, backgroundImage: artCss(p) }}
      className="absolute left-1/2 top-1/2 -ml-[8.5rem] -mt-[10.4rem] h-[20.8rem] w-[17rem] outline-offset-8 focus-visible:outline focus-visible:outline-2 sm:-ml-[23.6vh] sm:-mt-[28.85vh] sm:h-[57.7vh] sm:w-[47.2vh]">
      <div className="pointer-events-none absolute inset-0 shadow-[inset_0_0_0_1px_rgba(236,231,223,.08),inset_0_0_70px_rgba(0,0,0,.28),0_34px_70px_-24px_rgba(0,0,0,.7)]" />
    </motion.a>
  );
}

export default function PortfolioCarousel() {
  const reduce = useReducedMotion();
  const [gl, setGl] = useState(false);
  const [active, setActive] = useState(0);
  const progress = useMotionValue(0);
  const target = useRef(0);
  useEffect(() => { setGl(!reduce && canWebGL2()); }, [reduce]);

  const go = (i: number) => {
    target.current = i; setActive(((i % N) + N) % N);
    animate(progress, i, reduce ? { duration: 0.2 } : { type: "spring", stiffness: 120, damping: 20 });
  };
  const next = (d: number) => go(Math.round(target.current) + d);
  useEffect(() => {
    const k = (e: KeyboardEvent) => { if (e.key === "ArrowRight") next(1); if (e.key === "ArrowLeft") next(-1); };
    let lock = false;
    const w = (e: WheelEvent) => { const d = Math.abs(e.deltaX) > Math.abs(e.deltaY) ? e.deltaX : e.deltaY; if (lock || Math.abs(d) < 24) return; lock = true; next(d > 0 ? 1 : -1); setTimeout(() => (lock = false), 450); };
    addEventListener("keydown", k); addEventListener("wheel", w, { passive: true });
    return () => { removeEventListener("keydown", k); removeEventListener("wheel", w); };
  }, []);

  const p = projects[active];
  /** The thread scrolls with the pieces, same progress, same spring. */
  const trailShift = useTransform(progress, (v) => -wrap(v, N) * PATH.gap);
  return (
    <section role="region" aria-roledescription="carousel" aria-label="Selected work" className="f-sans relative h-screen min-h-[640px] w-full overflow-hidden text-[#ece7df]" style={{ background: "#0e0d0f" }}>
      {/* the room breathes with the piece on show */}
      <motion.div key={p.slug + "-tint"} aria-hidden initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 1 }}
        className="absolute inset-0" style={{ background: `radial-gradient(58% 52% at 50% 42%, ${p.palette[1]}3d, transparent 72%)` }} />

      <div className="absolute inset-0 [perspective:1600px]">
        <svg aria-hidden className="pointer-events-none absolute inset-0 h-full w-full" viewBox="0 0 100 100" preserveAspectRatio="none" style={{ filter: "blur(0.8px)" }}>
          <motion.g style={{ x: trailShift }} fill="none" stroke={p.palette[2]} strokeWidth="1.1">
            <path className="trail-a" d={TRAIL_A} vectorEffect="non-scaling-stroke" />
            <path className="trail-b" d={TRAIL_B} vectorEffect="non-scaling-stroke" />
            <path className="trail-c" d={TRAIL_C} vectorEffect="non-scaling-stroke" strokeWidth="0.8" />
          </motion.g>
        </svg>
        <motion.div className="absolute inset-0 cursor-grab touch-pan-y active:cursor-grabbing" drag="x" dragConstraints={{ left: 0, right: 0 }} dragElastic={0.2}
          onDragEnd={(_, i) => { const s = i.offset.x + i.velocity.x * 0.2; if (Math.abs(s) > 80) next(s < 0 ? 1 : -1); }}>
          {projects.map((pr, i) => <Artwork key={pr.slug} p={pr} i={i} progress={progress} gl={gl} onPick={go} />)}
        </motion.div>
        {gl && <Suspense fallback={null}><CrumpleCanvas projects={projects} progress={progress} /></Suspense>}
      </div>

      <div aria-hidden className="grain pointer-events-none absolute inset-0 opacity-[.1]" />
      <div aria-hidden className="pointer-events-none absolute inset-0" style={{ background: "radial-gradient(130% 100% at 50% 45%, transparent 42%, rgba(0,0,0,.78))" }} />

      {/* chrome */}
      <div className="pointer-events-none absolute inset-x-7 top-6 flex items-baseline justify-between">
        <span className="f-serif text-2xl italic leading-none">Studio<span className="ml-0.5 align-super text-[10px] not-italic">®</span></span>
        <span className="text-[11px] uppercase tracking-[.32em] text-[#ece7df]/55">Selected Work</span>
      </div>

      <motion.aside key={p.slug} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}
        className="pointer-events-none absolute bottom-7 left-7 hidden max-w-[17rem] md:block">
        <p className="text-[11px] uppercase tracking-[.3em] text-[#ece7df]/50">{p.category} · {p.year}</p>
        <h2 className="f-serif mt-1 text-[2.1rem] italic leading-none">{p.title}</h2>
        <p className="mt-2 text-[13px] leading-snug text-[#ece7df]/70">{p.client} — {p.tagline}</p>
      </motion.aside>

      <div className="absolute bottom-7 left-1/2 flex -translate-x-1/2 items-center gap-4">
        {["←", "→"].map((a, k) => (
          <button key={a} onClick={() => next(k ? 1 : -1)} aria-label={k ? "Next project" : "Previous project"}
            className="grid h-10 w-10 place-items-center rounded-full border border-[#ece7df]/25 text-[#ece7df]/80 backdrop-blur-sm transition hover:border-[#ece7df]/60 hover:text-[#ece7df] focus-visible:outline focus-visible:outline-2">{a}</button>
        ))}
        <span className="ml-2 text-sm tabular-nums tracking-[.22em] text-[#ece7df]/70">{pad(active + 1)} — {pad(N)}</span>
      </div>

      <div className="pointer-events-none absolute bottom-7 right-7 hidden text-right text-[11px] uppercase tracking-[.25em] text-[#ece7df]/45 md:block">{p.stack.join(" · ")}</div>
    </section>
  );
}

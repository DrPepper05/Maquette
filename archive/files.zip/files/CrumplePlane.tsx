import { useMemo, useRef } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import * as THREE from "three";
import type { MotionValue } from "motion/react";
import type { Project } from "./projects";
import { PATH } from "./projects";
import vert from "./shaders/crumple.vert?raw";
import frag from "./shaders/crumple.frag?raw";

export const wrap = (v: number, n: number) => ((v + n / 2) % n + n) % n - n / 2;
export const smooth = (a: number, b: number, x: number) => { const t = Math.min(1, Math.max(0, (x - a) / (b - a))); return t * t * (3 - 2 * t); };

export function CrumplePlane({ project, index, count, progress }: { project: Project; index: number; count: number; progress: MotionValue<number> }) {
  const mesh = useRef<THREE.Mesh>(null!);
  const { viewport } = useThree();
  const material = useMemo(() => new THREE.ShaderMaterial({
    vertexShader: vert, fragmentShader: frag, side: THREE.DoubleSide,
    uniforms: {
      uCrumple: { value: 1 }, uTime: { value: 0 }, uSeed: { value: index * 7.3 },
      uP0: { value: new THREE.Color(project.palette[0]) },
      uP1: { value: new THREE.Color(project.palette[1]) },
      uP2: { value: new THREE.Color(project.palette[2]) },
      uP3: { value: new THREE.Color(project.palette[3]) },
    },
  }), [project, index]);

  useFrame(({ clock }) => {
    const o = wrap(index - progress.get(), count), a = Math.abs(o);
    const crumple = smooth(0.08, 1.0, a), flat = 1 - crumple, t = clock.elapsedTime;
    material.uniforms.uCrumple.value = crumple;
    material.uniforms.uTime.value = t;
    mesh.current.visible = a < 2.6;
    const xU = (PATH.gap / 100) * viewport.width, yU = (PATH.amp / 100) * viewport.height;
    mesh.current.position.set(o * xU, -Math.sin(o * PATH.freq) * yU, -a * 0.6);
    mesh.current.rotation.set(0, -o * 0.55, (1 - crumple) * -0.06 + Math.sin(t * .25 + index) * .012 * flat);
    mesh.current.scale.setScalar(1 - Math.min(a, 1) * 0.1);
  });

  return (
    <mesh ref={mesh} material={material}>
      <planeGeometry args={[2.6, 3.18, 48, 60]} />
    </mesh>
  );
}

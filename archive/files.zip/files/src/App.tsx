import PortfolioCarousel from "../PortfolioCarousel";

export default function App() {
  return <PortfolioCarousel />;
}

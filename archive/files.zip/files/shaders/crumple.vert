uniform float uCrumple; uniform float uTime; uniform float uSeed;
varying vec2 vUv; varying vec3 vPos;
float h(vec3 p){ p=fract(p*.3183099+.1); p*=17.; return fract(p.x*p.y*p.z*(p.x+p.y+p.z)); }
float n(vec3 x){ vec3 i=floor(x), f=fract(x); f=f*f*(3.-2.*f);
  return mix(mix(mix(h(i),h(i+vec3(1,0,0)),f.x),mix(h(i+vec3(0,1,0)),h(i+vec3(1,1,0)),f.x),f.y),
             mix(mix(h(i+vec3(0,0,1)),h(i+vec3(1,0,1)),f.x),mix(h(i+vec3(0,1,1)),h(i+vec3(1,1,1)),f.x),f.y),f.z); }
void main(){
  vUv = uv; vec3 p = position;
  vec3 q = p*1.15 + uSeed + vec3(0.,0.,uTime*.08);
  float a = n(q*2.)-.5, b = n(q*4.7+9.)-.5;
  vec3 d = vec3(a, b, a+b*.8);
  p.xy *= mix(1., .78, uCrumple);            // paper contracts as it crumples
  p += d * vec3(.55,.55,1.3) * uCrumple;       // fold it
  vPos = p;
  gl_Position = projectionMatrix * modelViewMatrix * vec4(p,1.);
}

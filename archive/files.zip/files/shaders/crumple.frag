uniform float uCrumple; uniform float uTime; uniform float uSeed;
uniform vec3 uP0; uniform vec3 uP1; uniform vec3 uP2; uniform vec3 uP3;
varying vec2 vUv; varying vec3 vPos;

float h(vec3 p){ p=fract(p*.3183099+.1); p*=17.; return fract(p.x*p.y*p.z*(p.x+p.y+p.z)); }
float n(vec3 x){ vec3 i=floor(x), f=fract(x); f=f*f*(3.-2.*f);
  return mix(mix(mix(h(i),h(i+vec3(1,0,0)),f.x),mix(h(i+vec3(0,1,0)),h(i+vec3(1,1,0)),f.x),f.y),
             mix(mix(h(i+vec3(0,0,1)),h(i+vec3(1,0,1)),f.x),mix(h(i+vec3(0,1,1)),h(i+vec3(1,1,1)),f.x),f.y),f.z); }
float fbm(vec3 p){ float v=0., a=.55; for(int i=0;i<3;i++){ v+=a*n(p); p=p*2.02+vec3(1.7); a*=.5; } return v; }

void main(){
  vec2 uv = vUv;
  vec3 q = vec3(uv*2.3, uSeed*1.7);
  float t = uTime*.05;
  vec2 wp = vec2(fbm(q+vec3(0.,0.,t)), fbm(q+vec3(5.2,1.3,t*.8)));
  vec3 w = vec3(wp, (wp.x+wp.y)*.5);
  float f = fbm(q + w*1.7 + vec3(t*.4, 0., 0.));
  float g = fbm(q*1.6 + w*2.3 + vec3(0., t*.3, 0.));

  vec3 col = mix(uP3, uP0, smoothstep(.15,.75,f));          // painterly, soft fields
  col = mix(col, uP1, smoothstep(.35,.85,g)*.75);
  col = mix(col, uP2, smoothstep(.5,.98,f+g*.5)*.55);
  col += uP2 * pow(smoothstep(.45,1.,f), 3.)*.22;           // luminous passages

  float band = abs(uv.x*.75 + uv.y*.65 - (.2 + .6*fract(uTime*.015)));
  col += vec3(1.,.96,.88) * pow(1.-smoothstep(0.,.3,band), 4.) * .05;  // glass sheen

  col += (h(vec3(uv*891., uSeed))-.5)*.03;                  // canvas grain

  // modern museum frame: dark bevel, edge-lit rim, fine outer hairline
  float e = min(min(uv.x,1.-uv.x), min(uv.y,1.-uv.y));
  col *= mix(.82, 1., smoothstep(0., .018, e));
  col += uP2 * smoothstep(.006, .0025, abs(e - .014)) * .55;
  col += vec3(.9,.88,.82) * smoothstep(.002, .0008, abs(e - .0055)) * .25;

  vec3 nrm = normalize(cross(dFdx(vPos), dFdy(vPos)));            // flat facets = crumpled paper
  float l = dot(nrm, normalize(vec3(-.4,.7,.9)))*.5+.5;
  gl_FragColor = vec4(mix(col, col*mix(.55,1.15,l), uCrumple), 1.);
}

import { Canvas } from "@react-three/fiber";
import type { MotionValue } from "motion/react";
import { CrumplePlane } from "./CrumplePlane";
import type { Project } from "./projects";

export default function CrumpleCanvas({ projects, progress }: { projects: Project[]; progress: MotionValue<number> }) {
  return (
    <Canvas aria-hidden dpr={[1, 1.5]} camera={{ position: [0, 0, 8], fov: 38 }}
      gl={{ alpha: true, antialias: false, powerPreference: "high-performance" }} className="absolute! inset-0 z-[150] pointer-events-none">
      {projects.map((p, i) => <CrumplePlane key={p.slug} project={p} index={i} count={projects.length} progress={progress} />)}
    </Canvas>
  );
}

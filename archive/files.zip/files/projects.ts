export type Project = {
  slug: string; title: string; client: string; year: number;
  category: "Website" | "Automation" | "Software"; stack: string[];
  palette: [string, string, string, string]; // ground, mid, light, deep
  tagline: string; href: string;
};
export const projects: Project[] = [
  { slug: "northwind", title: "Northwind", client: "Northwind Logistics", year: 2026, category: "Software", stack: ["Next.js", "Postgres", "tRPC"], palette: ["#141d2e", "#3f6fa3", "#d9915b", "#0a0f1a"], tagline: "Fleet operations, one screen.", href: "/work/northwind" },
  { slug: "lumen", title: "Lumen", client: "Lumen Clinics", year: 2026, category: "Website", stack: ["Next.js", "Sanity"], palette: ["#2b1216", "#8e2f35", "#e0a458", "#15080b"], tagline: "Care that books itself.", href: "/work/lumen" },
  { slug: "forge", title: "Forge", client: "Forge Industrial", year: 2025, category: "Automation", stack: ["Python", "n8n", "AWS"], palette: ["#1c1a1e", "#7a6e62", "#c4552c", "#0d0b0e"], tagline: "14 hours of paperwork, zero.", href: "/work/forge" },
  { slug: "verdant", title: "Verdant", client: "Verdant Foods", year: 2025, category: "Website", stack: ["Astro", "Shopify"], palette: ["#12211a", "#3e7a52", "#c3d97a", "#08120d"], tagline: "Fresh, fast, headless.", href: "/work/verdant" },
  { slug: "atlas", title: "Atlas", client: "Atlas Finance", year: 2025, category: "Software", stack: ["React", "Node", "Stripe"], palette: ["#1d1626", "#6f5a9e", "#dcc9a2", "#0e0a14"], tagline: "Billing without the sprawl.", href: "/work/atlas" },
];
/** Carousel trajectory: horizontal step (vw), vertical amplitude (vh), one full wave per revolution. */
export const PATH = { gap: 31, amp: 11, freq: (2 * Math.PI) / projects.length };

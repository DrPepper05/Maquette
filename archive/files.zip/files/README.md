# Portfolio Albums Carousel
npm i react react-dom motion three @react-three/fiber tailwindcss
(Vite: `?raw` shader imports work out of the box. Next.js: add `raw-loader`/asset/source rule for .vert/.frag.)
Usage: `<PortfolioCarousel />` — edit `projects.ts`. WebGL crumple loads lazily; falls back to CSS 3D on no-WebGL2 / reduced-motion.
